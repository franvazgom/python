from django.shortcuts import render
from .models import Service

def service_list(request):
    service_list = Service.objects.all()
    return render(request, 'services/service_list.html', {'service_list':service_list})


